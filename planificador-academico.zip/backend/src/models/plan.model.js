const { getDb } = require('../database/db');

const PlanModel = {

  create({ estudianteId, cuatrimestreObjetivo, estrategia }) {
    const db = getDb();
    return db.prepare(`
      INSERT INTO plan (estudiante_id, cuatrimestre_objetivo, estrategia)
      VALUES (?,?,?)
    `).run(estudianteId, cuatrimestreObjetivo || null, estrategia || null);
  },

  findById(id) {
    const db = getDb();
    const plan = db.prepare(`SELECT * FROM plan WHERE id = ?`).get(id);
    if (!plan) return null;

    const materias = db.prepare(`
      SELECT pm.*, m.codigo, m.nombre, m.anio, m.cuatrimestre,
             m.horas_semanales, m.dificultad
      FROM plan_materia pm
      JOIN materia m ON m.id = pm.materia_id
      WHERE pm.plan_id = ?
    `).all(id);

    const bloques = db.prepare(`
      SELECT * FROM plan_semanal WHERE plan_id = ?
      ORDER BY CASE dia
        WHEN 'LUNES' THEN 1 WHEN 'MARTES' THEN 2 WHEN 'MIERCOLES' THEN 3
        WHEN 'JUEVES' THEN 4 WHEN 'VIERNES' THEN 5 WHEN 'SABADO' THEN 6
        WHEN 'DOMINGO' THEN 7 END, id
    `).all(id);

    return { ...plan, materias, bloques };
  },

  findByEstudiante(estudianteId) {
    const db = getDb();
    return db.prepare(`
      SELECT * FROM plan WHERE estudiante_id = ?
      ORDER BY fecha_generacion DESC
    `).all(estudianteId);
  },

  addMateria({ planId, materiaId, recomendada, motivoRechazo, horasCursada, horasEstudio }) {
    const db = getDb();
    return db.prepare(`
      INSERT OR REPLACE INTO plan_materia
        (plan_id, materia_id, recomendada, motivo_rechazo, horas_cursada, horas_estudio)
      VALUES (?,?,?,?,?,?)
    `).run(planId, materiaId, recomendada ? 1 : 0,
           motivoRechazo || null, horasCursada || null, horasEstudio || null);
  },

  addBloque({ planId, dia, actividad, horas }) {
    const db = getDb();
    return db.prepare(`
      INSERT INTO plan_semanal (plan_id, dia, actividad, horas)
      VALUES (?,?,?,?)
    `).run(planId, dia, actividad, horas);
  },

  updateExplicacion(planId, explicacion, horasEstudioSemanales) {
    const db = getDb();
    return db.prepare(`
      UPDATE plan SET explicacion_ia = ?, horas_estudio_semanales = ?
      WHERE id = ?
    `).run(explicacion, horasEstudioSemanales, planId);
  }

};

module.exports = PlanModel;
