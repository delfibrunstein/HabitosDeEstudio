const { getDb } = require('../database/db');

const MateriaModel = {

  findAll(carreraId) {
    const db = getDb();
    const materias = db.prepare(`
      SELECT m.*,
        GROUP_CONCAT(c.correlativa_id) AS correlativas_ids
      FROM materia m
      LEFT JOIN correlatividad c ON c.materia_id = m.id
      WHERE m.carrera_id = ?
      GROUP BY m.id
      ORDER BY m.anio, m.cuatrimestre, m.nombre
    `).all(carreraId);

    return materias.map(m => ({
      ...m,
      promocionable: m.promocionable === 1,
      correlativas_ids: m.correlativas_ids
        ? m.correlativas_ids.split(',').map(Number)
        : []
    }));
  },

  findById(id) {
    const db = getDb();
    const m = db.prepare(`SELECT * FROM materia WHERE id = ?`).get(id);
    if (!m) return null;
    const corrs = db.prepare(
      `SELECT correlativa_id FROM correlatividad WHERE materia_id = ?`
    ).all(id);
    return {
      ...m,
      promocionable: m.promocionable === 1,
      correlativas_ids: corrs.map(c => c.correlativa_id)
    };
  },

  findByCodigoYCarrera(codigo, carreraId) {
    const db = getDb();
    return db.prepare(
      `SELECT * FROM materia WHERE codigo = ? AND carrera_id = ?`
    ).get(codigo, carreraId);
  },

  create({ codigo, nombre, anio, cuatrimestre, horasSemanales, dificultad, promocionable, carreraId }) {
    const db = getDb();
    return db.prepare(`
      INSERT INTO materia
        (codigo, nombre, anio, cuatrimestre, horas_semanales, dificultad, promocionable, carrera_id)
      VALUES (?,?,?,?,?,?,?,?)
    `).run(codigo, nombre, anio, cuatrimestre, horasSemanales, dificultad, promocionable ? 1 : 0, carreraId);
  },

  insertCorrelatividad(materiaId, correlativaId) {
    const db = getDb();
    return db.prepare(
      `INSERT OR IGNORE INTO correlatividad (materia_id, correlativa_id) VALUES (?,?)`
    ).run(materiaId, correlativaId);
  },

  deleteByCarrera(carreraId) {
    const db = getDb();
    return db.prepare(`DELETE FROM materia WHERE carrera_id = ?`).run(carreraId);
  }

};

module.exports = MateriaModel;
