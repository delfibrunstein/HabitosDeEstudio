const { getDb } = require('../database/db');

const EstudianteModel = {

  findById(id) {
    const db = getDb();
    return db.prepare(`
      SELECT e.*, c.nombre AS carrera_nombre
      FROM estudiante e
      LEFT JOIN carrera c ON c.id = e.carrera_id
      WHERE e.id = ?
    `).get(id);
  },

  findByLegajo(legajo) {
    const db = getDb();
    return db.prepare(`SELECT * FROM estudiante WHERE legajo = ?`).get(legajo);
  },

  create(data) {
    const db = getDb();
    const { nombre, dni, email, edad, nacimiento, trabaja,
            legajo, horasLaborales, horasTransporte,
            objetivo, preferenciaCursada, carreraId } = data;
    return db.prepare(`
      INSERT INTO estudiante
        (nombre, dni, email, edad, nacimiento, trabaja, legajo,
         horas_laborales, horas_transporte, objetivo, preferencia_cursada, carrera_id)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
    `).run(nombre, dni, email, edad, nacimiento, trabaja ? 1 : 0, legajo,
           horasLaborales || 0, horasTransporte || 0,
           objetivo || 'MANTENER_PROMEDIO',
           preferenciaCursada || 'EQUILIBRADA',
           carreraId);
  },

  update(id, data) {
    const db = getDb();
    const fields = [];
    const values = [];

    const allowed = {
      nombre: 'nombre', dni: 'dni', email: 'email', edad: 'edad',
      nacimiento: 'nacimiento', trabaja: 'trabaja', legajo: 'legajo',
      horasLaborales: 'horas_laborales', horasTransporte: 'horas_transporte',
      objetivo: 'objetivo', preferenciaCursada: 'preferencia_cursada',
      carreraId: 'carrera_id'
    };

    for (const [key, col] of Object.entries(allowed)) {
      if (data[key] !== undefined) {
        fields.push(`${col} = ?`);
        values.push(key === 'trabaja' ? (data[key] ? 1 : 0) : data[key]);
      }
    }

    if (!fields.length) return null;
    values.push(id);
    return db.prepare(
      `UPDATE estudiante SET ${fields.join(', ')} WHERE id = ?`
    ).run(...values);
  },

  // ── Disponibilidad ──────────────────────────────────────────────────────────

  getDisponibilidad(estudianteId) {
    const db = getDb();
    return db.prepare(
      `SELECT * FROM disponibilidad_usuario WHERE estudiante_id = ? ORDER BY
       CASE dia
         WHEN 'LUNES'     THEN 1 WHEN 'MARTES'    THEN 2
         WHEN 'MIERCOLES' THEN 3 WHEN 'JUEVES'    THEN 4
         WHEN 'VIERNES'   THEN 5 WHEN 'SABADO'    THEN 6
         WHEN 'DOMINGO'   THEN 7
       END`
    ).all(estudianteId);
  },

  upsertDisponibilidad(estudianteId, dia, horasDisponibles) {
    const db = getDb();
    return db.prepare(`
      INSERT INTO disponibilidad_usuario (estudiante_id, dia, horas_disponibles)
      VALUES (?,?,?)
      ON CONFLICT(estudiante_id, dia) DO UPDATE SET horas_disponibles = excluded.horas_disponibles
    `).run(estudianteId, dia, horasDisponibles);
  },

  // ── Materias del estudiante ─────────────────────────────────────────────────

  getMateriasConEstado(estudianteId) {
    const db = getDb();
    return db.prepare(`
      SELECT m.*, ma.estado, ma.nota, ma.cuatrimestre_aprobado
      FROM materia m
      LEFT JOIN materia_aprobada ma
        ON ma.materia_id = m.id AND ma.estudiante_id = ?
      WHERE m.carrera_id = (
        SELECT carrera_id FROM estudiante WHERE id = ?
      )
      ORDER BY m.anio, m.cuatrimestre
    `).all(estudianteId, estudianteId);
  },

  upsertMateriaEstado(estudianteId, materiaId, estado, nota, cuatrimestreAprobado) {
    const db = getDb();
    return db.prepare(`
      INSERT INTO materia_aprobada
        (estudiante_id, materia_id, estado, nota, cuatrimestre_aprobado)
      VALUES (?,?,?,?,?)
      ON CONFLICT(estudiante_id, materia_id)
      DO UPDATE SET
        estado = excluded.estado,
        nota = excluded.nota,
        cuatrimestre_aprobado = excluded.cuatrimestre_aprobado
    `).run(estudianteId, materiaId, estado, nota || null, cuatrimestreAprobado || null);
  },

  getMateriasAprobadas(estudianteId) {
    const db = getDb();
    return db.prepare(`
      SELECT materia_id FROM materia_aprobada
      WHERE estudiante_id = ? AND estado = 'APROBADA'
    `).all(estudianteId).map(r => r.materia_id);
  }
};

module.exports = EstudianteModel;
