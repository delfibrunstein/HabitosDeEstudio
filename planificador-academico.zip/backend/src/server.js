require('dotenv').config();
const app = require('./app');
const { initDatabase } = require('./database/init');

const PORT = process.env.PORT || 3001;

async function start() {
  try {
    initDatabase();
    console.log('[DB] Base de datos inicializada');

    app.listen(PORT, () => {
      console.log(`[SERVER] Corriendo en http://localhost:${PORT}`);
      console.log(`[SERVER] Health check: http://localhost:${PORT}/api/health`);
    });
  } catch (err) {
    console.error('[FATAL] No se pudo iniciar el servidor:', err.message);
    process.exit(1);
  }
}

start();
