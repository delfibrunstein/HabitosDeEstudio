const { getDb } = require('./db');

function initDatabase() {
  const db = getDb();

  db.exec(`
    -- ─────────────────────────────────────────────────────
    -- Dominio académico
    -- ─────────────────────────────────────────────────────

    CREATE TABLE IF NOT EXISTS universidad (
      id      INTEGER PRIMARY KEY AUTOINCREMENT,
      nombre  TEXT NOT NULL UNIQUE
    );

    CREATE TABLE IF NOT EXISTS carrera (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      nombre        TEXT NOT NULL,
      universidad_id INTEGER REFERENCES universidad(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS materia (
      id              INTEGER PRIMARY KEY AUTOINCREMENT,
      codigo          TEXT NOT NULL,
      nombre          TEXT NOT NULL,
      anio            INTEGER NOT NULL,
      cuatrimestre    INTEGER NOT NULL CHECK(cuatrimestre IN (1,2)),
      horas_semanales REAL NOT NULL,
      dificultad      TEXT NOT NULL CHECK(dificultad IN ('BAJA','MEDIA','ALTA','CRITICA')),
      promocionable   INTEGER NOT NULL DEFAULT 0,
      carrera_id      INTEGER REFERENCES carrera(id) ON DELETE CASCADE,
      UNIQUE(codigo, carrera_id)
    );

    -- Correlatividades (muchos a muchos)
    CREATE TABLE IF NOT EXISTS correlatividad (
      materia_id     INTEGER NOT NULL REFERENCES materia(id) ON DELETE CASCADE,
      correlativa_id INTEGER NOT NULL REFERENCES materia(id) ON DELETE CASCADE,
      PRIMARY KEY (materia_id, correlativa_id)
    );

    -- ─────────────────────────────────────────────────────
    -- Perfil del estudiante
    -- ─────────────────────────────────────────────────────

    CREATE TABLE IF NOT EXISTS estudiante (
      id                  INTEGER PRIMARY KEY AUTOINCREMENT,
      nombre              TEXT NOT NULL,
      dni                 TEXT UNIQUE,
      email               TEXT,
      edad                INTEGER,
      nacimiento          TEXT,
      trabaja             INTEGER NOT NULL DEFAULT 0,
      legajo              TEXT UNIQUE,
      carga               REAL DEFAULT 0,
      horas_transporte    REAL DEFAULT 0,
      horas_laborales     REAL DEFAULT 0,
      objetivo            TEXT DEFAULT 'MANTENER_PROMEDIO'
                          CHECK(objetivo IN (
                            'AVANZAR_RAPIDO','MANTENER_PROMEDIO',
                            'EVITAR_SOBRECARGA','ORDENAR_HABITOS'
                          )),
      preferencia_cursada TEXT DEFAULT 'EQUILIBRADA'
                          CHECK(preferencia_cursada IN (
                            'INTENSIVA','EQUILIBRADA','LIVIANA'
                          )),
      carrera_id          INTEGER REFERENCES carrera(id)
    );

    -- Disponibilidad semanal (7 filas por estudiante)
    CREATE TABLE IF NOT EXISTS disponibilidad_usuario (
      id                INTEGER PRIMARY KEY AUTOINCREMENT,
      estudiante_id     INTEGER NOT NULL REFERENCES estudiante(id) ON DELETE CASCADE,
      dia               TEXT NOT NULL CHECK(dia IN (
                          'LUNES','MARTES','MIERCOLES','JUEVES',
                          'VIERNES','SABADO','DOMINGO'
                        )),
      horas_disponibles REAL NOT NULL DEFAULT 0,
      UNIQUE(estudiante_id, dia)
    );

    -- Historial académico del estudiante
    CREATE TABLE IF NOT EXISTS materia_aprobada (
      id                    INTEGER PRIMARY KEY AUTOINCREMENT,
      estudiante_id         INTEGER NOT NULL REFERENCES estudiante(id) ON DELETE CASCADE,
      materia_id            INTEGER NOT NULL REFERENCES materia(id) ON DELETE CASCADE,
      nota                  REAL,
      estado                TEXT NOT NULL CHECK(estado IN (
                              'APROBADA','REGULARIZADA','RECURSADA','EN_CURSO'
                            )),
      cuatrimestre_aprobado INTEGER,
      UNIQUE(estudiante_id, materia_id)
    );

    -- ─────────────────────────────────────────────────────
    -- Plan de estudios cargado (archivo Excel)
    -- ─────────────────────────────────────────────────────

    CREATE TABLE IF NOT EXISTS plan_estudio (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      nombre_archivo TEXT NOT NULL,
      fecha_carga   TEXT NOT NULL DEFAULT (datetime('now')),
      carrera_id    INTEGER REFERENCES carrera(id)
    );

    -- ─────────────────────────────────────────────────────
    -- Recomendación generada
    -- ─────────────────────────────────────────────────────

    CREATE TABLE IF NOT EXISTS plan (
      id                      INTEGER PRIMARY KEY AUTOINCREMENT,
      estudiante_id           INTEGER NOT NULL REFERENCES estudiante(id) ON DELETE CASCADE,
      fecha_generacion        TEXT NOT NULL DEFAULT (datetime('now')),
      cuatrimestre_objetivo   INTEGER,
      horas_estudio_semanales REAL,
      explicacion_ia          TEXT,
      estrategia              TEXT
    );

    -- Materias recomendadas en un plan
    CREATE TABLE IF NOT EXISTS plan_materia (
      plan_id    INTEGER NOT NULL REFERENCES plan(id) ON DELETE CASCADE,
      materia_id INTEGER NOT NULL REFERENCES materia(id),
      recomendada INTEGER NOT NULL DEFAULT 1,
      motivo_rechazo TEXT,
      horas_cursada  REAL,
      horas_estudio  REAL,
      PRIMARY KEY (plan_id, materia_id)
    );

    -- Bloques semanales del plan
    CREATE TABLE IF NOT EXISTS plan_semanal (
      id        INTEGER PRIMARY KEY AUTOINCREMENT,
      plan_id   INTEGER NOT NULL REFERENCES plan(id) ON DELETE CASCADE,
      dia       TEXT NOT NULL CHECK(dia IN (
                  'LUNES','MARTES','MIERCOLES','JUEVES',
                  'VIERNES','SABADO','DOMINGO'
                )),
      actividad TEXT NOT NULL,
      horas     REAL NOT NULL
    );
  `);
}

module.exports = { initDatabase };
