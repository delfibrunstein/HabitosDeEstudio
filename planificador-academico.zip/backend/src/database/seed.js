require('dotenv').config();
const { initDatabase } = require('./init');
const { getDb } = require('./db');

initDatabase();
const db = getDb();

console.log('[SEED] Insertando datos de prueba...');

// ── Universidad y Carrera ─────────────────────────────────────────────────────
const uniId = db.prepare(
  `INSERT OR IGNORE INTO universidad (nombre) VALUES (?)`
).run('Universidad Tecnologica Nacional').lastInsertRowid
  || db.prepare(`SELECT id FROM universidad WHERE nombre = ?`)
       .get('Universidad Tecnologica Nacional').id;

const carreraId = db.prepare(
  `INSERT OR IGNORE INTO carrera (nombre, universidad_id) VALUES (?,?)`
).run('Ingenieria en Sistemas de Informacion', uniId).lastInsertRowid
  || db.prepare(`SELECT id FROM carrera WHERE nombre = ?`)
       .get('Ingenieria en Sistemas de Informacion').id;

// ── Materias de prueba ────────────────────────────────────────────────────────
const materias = [
  { codigo:'ANA1', nombre:'Analisis Matematico 1',    anio:1, cuatri:1, hs:6, dif:'ALTA',   prom:0, corrs:[] },
  { codigo:'ALG1', nombre:'Algebra y Geometria Analitica', anio:1, cuatri:1, hs:6, dif:'ALTA',  prom:0, corrs:[] },
  { codigo:'SIS1', nombre:'Sistemas y Organizaciones',  anio:1, cuatri:1, hs:4, dif:'BAJA',  prom:1, corrs:[] },
  { codigo:'TEC1', nombre:'Tecnologia de la Informacion',anio:1, cuatri:1, hs:4, dif:'BAJA',  prom:1, corrs:[] },
  { codigo:'ANA2', nombre:'Analisis Matematico 2',    anio:1, cuatri:2, hs:6, dif:'ALTA',   prom:0, corrs:['ANA1'] },
  { codigo:'ALG2', nombre:'Algebra Lineal',            anio:1, cuatri:2, hs:4, dif:'MEDIA',  prom:0, corrs:['ALG1'] },
  { codigo:'FIS1', nombre:'Fisica 1',                  anio:1, cuatri:2, hs:6, dif:'ALTA',   prom:0, corrs:['ANA1'] },
  { codigo:'PROG1',nombre:'Programacion 1',            anio:2, cuatri:1, hs:6, dif:'MEDIA',  prom:1, corrs:['TEC1'] },
  { codigo:'EDA',  nombre:'Estructura de Datos',       anio:2, cuatri:1, hs:6, dif:'ALTA',   prom:0, corrs:['PROG1'] },
  { codigo:'BD1',  nombre:'Bases de Datos 1',          anio:2, cuatri:2, hs:6, dif:'MEDIA',  prom:1, corrs:['PROG1'] },
  { codigo:'PROG2',nombre:'Programacion 2',            anio:2, cuatri:2, hs:6, dif:'ALTA',   prom:0, corrs:['PROG1'] },
  { codigo:'SO1',  nombre:'Sistemas Operativos 1',     anio:3, cuatri:1, hs:4, dif:'MEDIA',  prom:0, corrs:['EDA'] },
  { codigo:'REDES',nombre:'Redes y Comunicaciones',    anio:3, cuatri:1, hs:4, dif:'MEDIA',  prom:0, corrs:['FIS1'] },
  { codigo:'ING1', nombre:'Ingenieria de Software 1',  anio:3, cuatri:2, hs:6, dif:'MEDIA',  prom:1, corrs:['BD1','PROG2'] },
  { codigo:'BD2',  nombre:'Bases de Datos 2',          anio:3, cuatri:2, hs:4, dif:'CRITICA',prom:0, corrs:['BD1'] },
];

const insertMateria = db.prepare(`
  INSERT OR IGNORE INTO materia
    (codigo, nombre, anio, cuatrimestre, horas_semanales, dificultad, promocionable, carrera_id)
  VALUES (?,?,?,?,?,?,?,?)
`);

const getMateria = db.prepare(`SELECT id FROM materia WHERE codigo=? AND carrera_id=?`);

const insertCorr = db.prepare(`
  INSERT OR IGNORE INTO correlatividad (materia_id, correlativa_id) VALUES (?,?)
`);

// Insertar materias
const insertMaterias = db.transaction(() => {
  for (const m of materias) {
    insertMateria.run(m.codigo, m.nombre, m.anio, m.cuatri, m.hs, m.dif, m.prom ? 1 : 0, carreraId);
  }
});
insertMaterias();

// Insertar correlatividades
const insertCorrs = db.transaction(() => {
  for (const m of materias) {
    const row = getMateria.get(m.codigo, carreraId);
    if (!row) continue;
    for (const cCodigo of m.corrs) {
      const corrRow = getMateria.get(cCodigo, carreraId);
      if (corrRow) insertCorr.run(row.id, corrRow.id);
    }
  }
});
insertCorrs();

// ── Estudiante de prueba ──────────────────────────────────────────────────────
const estId = db.prepare(`
  INSERT OR IGNORE INTO estudiante
    (nombre, dni, email, trabaja, legajo, horas_laborales, horas_transporte,
     objetivo, preferencia_cursada, carrera_id)
  VALUES (?,?,?,?,?,?,?,?,?,?)
`).run('Juan Perez','12345678','juan@email.com',1,'SIS001',30,1,
       'EVITAR_SOBRECARGA','EQUILIBRADA', carreraId).lastInsertRowid
  || db.prepare(`SELECT id FROM estudiante WHERE legajo='SIS001'`).get().id;

// Disponibilidad semanal
const dias = ['LUNES','MARTES','MIERCOLES','JUEVES','VIERNES','SABADO','DOMINGO'];
const horas = [2, 0, 3, 0, 3, 5, 4]; // trabaja lunes y martes tardes
const insertDisp = db.prepare(`
  INSERT OR IGNORE INTO disponibilidad_usuario (estudiante_id, dia, horas_disponibles)
  VALUES (?,?,?)
`);
dias.forEach((d, i) => insertDisp.run(estId, d, horas[i]));

// Materias aprobadas (primer año completo)
const aprobadas = ['ANA1','ALG1','SIS1','TEC1','ANA2','ALG2','FIS1'];
const insertAprob = db.prepare(`
  INSERT OR IGNORE INTO materia_aprobada
    (estudiante_id, materia_id, nota, estado, cuatrimestre_aprobado)
  VALUES (?,?,?,?,?)
`);
db.transaction(() => {
  for (const cod of aprobadas) {
    const mat = getMateria.get(cod, carreraId);
    if (mat) insertAprob.run(estId, mat.id, 7, 'APROBADA', 1);
  }
})();

// PROG1 regularizada
db.transaction(() => {
  const mat = getMateria.get('PROG1', carreraId);
  if (mat) insertAprob.run(estId, mat.id, null, 'REGULARIZADA', 2);
})();

console.log('[SEED] Datos de prueba insertados correctamente.');
console.log(`[SEED] Estudiante ID: ${estId} | Carrera ID: ${carreraId}`);
