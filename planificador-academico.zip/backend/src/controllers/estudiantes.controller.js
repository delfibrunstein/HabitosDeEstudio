const EstudianteModel = require('../models/estudiante.model');
const { getDb } = require('../database/db');

const EstudiantesController = {

  // POST /api/estudiantes
  async crear(req, res, next) {
    try {
      const result = EstudianteModel.create(req.body);
      const estudiante = EstudianteModel.findById(result.lastInsertRowid);
      res.status(201).json({ ok: true, estudiante });
    } catch (err) {
      if (err.message.includes('UNIQUE')) {
        return res.status(409).json({ error: 'Ya existe un estudiante con ese legajo o DNI.' });
      }
      next(err);
    }
  },

  // PUT /api/estudiantes/:id
  async actualizar(req, res, next) {
    try {
      const { id } = req.params;
      EstudianteModel.update(Number(id), req.body);
      const estudiante = EstudianteModel.findById(Number(id));
      if (!estudiante) return res.status(404).json({ error: 'Estudiante no encontrado.' });
      res.json({ ok: true, estudiante });
    } catch (err) { next(err); }
  },

  // GET /api/estudiantes/:id
  async obtener(req, res, next) {
    try {
      const estudiante = EstudianteModel.findById(Number(req.params.id));
      if (!estudiante) return res.status(404).json({ error: 'Estudiante no encontrado.' });
      res.json({ ok: true, estudiante });
    } catch (err) { next(err); }
  },

  // POST /api/estudiantes/:id/disponibilidad
  async guardarDisponibilidad(req, res, next) {
    try {
      const estudianteId = Number(req.params.id);
      const { disponibilidad } = req.body;
      // disponibilidad: [{ dia: 'LUNES', horasDisponibles: 3 }, ...]

      const DIAS = ['LUNES','MARTES','MIERCOLES','JUEVES','VIERNES','SABADO','DOMINGO'];
      const errors = [];

      for (const item of disponibilidad) {
        if (!DIAS.includes(item.dia)) {
          errors.push(`Dia invalido: ${item.dia}`);
          continue;
        }
        if (item.horasDisponibles < 0 || item.horasDisponibles > 24) {
          errors.push(`Horas invalidas para ${item.dia}`);
          continue;
        }
        EstudianteModel.upsertDisponibilidad(estudianteId, item.dia, item.horasDisponibles);
      }

      if (errors.length) return res.status(400).json({ error: errors.join('; ') });

      const guardado = EstudianteModel.getDisponibilidad(estudianteId);
      res.json({ ok: true, disponibilidad: guardado });
    } catch (err) { next(err); }
  },

  // GET /api/estudiantes/:id/disponibilidad
  async obtenerDisponibilidad(req, res, next) {
    try {
      const disponibilidad = EstudianteModel.getDisponibilidad(Number(req.params.id));
      res.json({ ok: true, disponibilidad });
    } catch (err) { next(err); }
  },

  // POST /api/estudiantes/:id/materias
  async guardarMaterias(req, res, next) {
    try {
      const estudianteId = Number(req.params.id);
      const { materias } = req.body;
      // materias: [{ materiaId, estado, nota, cuatrimestreAprobado }]

      const ESTADOS = ['APROBADA','REGULARIZADA','RECURSADA','EN_CURSO'];
      for (const m of materias) {
        if (!ESTADOS.includes(m.estado)) {
          return res.status(400).json({ error: `Estado invalido: ${m.estado}` });
        }
        EstudianteModel.upsertMateriaEstado(
          estudianteId, m.materiaId, m.estado, m.nota, m.cuatrimestreAprobado
        );
      }

      res.json({ ok: true, guardadas: materias.length });
    } catch (err) { next(err); }
  },

  // GET /api/estudiantes/:id/materias
  async obtenerMaterias(req, res, next) {
    try {
      const materias = EstudianteModel.getMateriasConEstado(Number(req.params.id));
      res.json({ ok: true, materias });
    } catch (err) { next(err); }
  },

  // GET /api/estudiantes/:id/carreras (para selector)
  async listarCarreras(req, res, next) {
    try {
      const db = getDb();
      const carreras = db.prepare(`
        SELECT c.*, u.nombre AS universidad_nombre
        FROM carrera c
        JOIN universidad u ON u.id = c.universidad_id
        ORDER BY c.nombre
      `).all();
      res.json({ ok: true, carreras });
    } catch (err) { next(err); }
  }
};

module.exports = EstudiantesController;
