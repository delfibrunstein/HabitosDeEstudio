const EstudianteModel = require('../models/estudiante.model');
const MateriaModel    = require('../models/materia.model');
const PlanModel       = require('../models/plan.model');

const EstrAvanceRapido     = require('../strategies/EstrAvanceRapido');
const EstrAvanceModerado   = require('../strategies/EstrAvanceModerado');
const EstrAvanceLento      = require('../strategies/EstrAvanceLento');
const EstrAvanceConTrabajo = require('../strategies/EstrAvanceConTrabajo');

const ESTRATEGIAS = {
  AVANZAR_RAPIDO:      () => new EstrAvanceRapido(),
  MANTENER_PROMEDIO:   () => new EstrAvanceModerado(),
  EVITAR_SOBRECARGA:   () => new EstrAvanceLento(),
  ORDENAR_HABITOS:     () => new EstrAvanceLento(),
};

const DIAS = ['LUNES','MARTES','MIERCOLES','JUEVES','VIERNES','SABADO','DOMINGO'];

const RecomendadorService = {

  async generar(estudianteId) {
    // 1. Cargar contexto
    const estudiante   = EstudianteModel.findById(estudianteId);
    if (!estudiante) throw new Error('Estudiante no encontrado.');

    const disponibilidad = EstudianteModel.getDisponibilidad(estudianteId);
    const aprobadas      = EstudianteModel.getMateriasAprobadas(estudianteId);
    const materias       = MateriaModel.findAll(estudiante.carrera_id);

    if (!materias.length) throw new Error('No hay materias cargadas para esta carrera.');

    // 2. Seleccionar estrategia (patrón Strategy)
    const objetivo       = estudiante.objetivo || 'MANTENER_PROMEDIO';
    const usarTrabajo    = estudiante.trabaja && (estudiante.horas_laborales || 0) > 0;
    const estrategiaKey  = usarTrabajo ? 'AVANZAR_RAPIDO' : objetivo; // si trabaja, forzamos ConTrabajo
    const estrategia     = usarTrabajo
      ? new EstrAvanceConTrabajo()
      : (ESTRATEGIAS[objetivo] ? ESTRATEGIAS[objetivo]() : new EstrAvanceModerado());

    // 3. Ejecutar recomendación
    const { recomendadas, noRecomendadas, horasAcumuladas } =
      estrategia.recomendar(estudiante, materias, aprobadas, disponibilidad);

    // 4. Persistir el plan
    const planResult = PlanModel.create({
      estudianteId,
      estrategia: objetivo,
    });
    const planId = planResult.lastInsertRowid;

    for (const m of recomendadas) {
      PlanModel.addMateria({
        planId, materiaId: m.id,
        recomendada: true,
        horasCursada: m.horas_semanales,
        horasEstudio: m.horas_estudio
      });
    }
    for (const m of noRecomendadas) {
      PlanModel.addMateria({
        planId, materiaId: m.id,
        recomendada: false,
        motivoRechazo: m.motivo_rechazo
      });
    }

    // 5. Generar plan semanal
    const bloques = this._generarPlanSemanal(recomendadas, disponibilidad);
    for (const b of bloques) {
      PlanModel.addBloque({ planId, ...b });
    }

    // 6. Generar explicación por reglas
    const explicacion = this._explicarPorReglas(estudiante, recomendadas, noRecomendadas, objetivo);
    PlanModel.updateExplicacion(planId, explicacion, horasAcumuladas);

    return PlanModel.findById(planId);
  },

  // ── Generador del plan semanal ──────────────────────────────────────────────
  _generarPlanSemanal(materiasRecomendadas, disponibilidad) {
    const bloques = [];
    const dispMap = {};
    for (const d of disponibilidad) dispMap[d.dia] = d.horas_disponibles;

    // Distribuir materias entre los días disponibles
    const diasConHoras = DIAS.filter(d => (dispMap[d] || 0) > 0);
    if (!diasConHoras.length || !materiasRecomendadas.length) return bloques;

    let diaIndex = 0;

    for (const materia of materiasRecomendadas) {
      const hsEstudio   = materia.horas_estudio || 0;
      const hsCursada   = materia.horas_semanales || 0;

      // Bloque de cursada (fijo, va al primer día disponible)
      const diaCursada = diasConHoras[diaIndex % diasConHoras.length];
      bloques.push({
        dia:       diaCursada,
        actividad: `Cursada: ${materia.nombre}`,
        horas:     hsCursada
      });
      diaIndex++;

      // Bloque de estudio (siguiente día)
      if (hsEstudio > 0) {
        const diaEstudio = diasConHoras[diaIndex % diasConHoras.length];
        bloques.push({
          dia:       diaEstudio,
          actividad: `Estudio: ${materia.nombre}`,
          horas:     Math.round(hsEstudio * 10) / 10
        });
        diaIndex++;
      }
    }

    return bloques;
  },

  // ── Explicación por reglas (fallback si Ollama no está disponible) ─────────
  _explicarPorReglas(estudiante, recomendadas, noRecomendadas, objetivo) {
    const nombres = recomendadas.map(m => m.nombre).join(', ');
    const total   = recomendadas.reduce((s, m) =>
      s + m.horas_semanales + (m.horas_estudio || 0), 0
    );

    const LABELS = {
      AVANZAR_RAPIDO:    'avanzar rápido',
      MANTENER_PROMEDIO: 'mantener promedio',
      EVITAR_SOBRECARGA: 'evitar sobrecarga',
      ORDENAR_HABITOS:   'ordenar hábitos'
    };
    const label = LABELS[objetivo] || 'equilibrado';

    let texto = recomendadas.length
      ? `Para tu objetivo de "${label}", se recomiendan ${recomendadas.length} materia(s): ${nombres}. ` +
        `La carga total estimada es de ${total.toFixed(1)} horas semanales (cursada + estudio).`
      : `No se encontraron materias recomendables para el próximo cuatrimestre con tu disponibilidad actual.`;

    if (noRecomendadas.length) {
      const motivos = [...new Set(noRecomendadas.map(m => m.motivo_rechazo).filter(Boolean))];
      texto += ` Algunas materias no fueron incluidas por los siguientes motivos: ${motivos.join('; ')}.`;
    }

    if (estudiante.trabaja && (estudiante.horas_laborales || 0) > 30) {
      texto += ` Se consideró que trabajás más de 30 horas semanales, por lo que se priorizó una carga académica moderada.`;
    }

    return texto;
  }
};

module.exports = RecomendadorService;
