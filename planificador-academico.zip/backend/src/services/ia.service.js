const PlanModel = require('../models/plan.model');

const OLLAMA_URL   = process.env.OLLAMA_URL   || 'http://localhost:11434';
const OLLAMA_MODEL = process.env.OLLAMA_MODEL || 'llama3.1';
const TIMEOUT_MS   = 8000;

const IaService = {

  async explicar(planId) {
    const plan = PlanModel.findById(planId);
    if (!plan) throw new Error('Plan no encontrado.');

    const prompt = this._construirPrompt(plan);

    // Intentar Ollama primero
    try {
      const respuesta = await this._llamarOllama(prompt);
      if (respuesta) {
        PlanModel.updateExplicacion(planId, respuesta, plan.horas_estudio_semanales);
        return { fuente: 'ollama', texto: respuesta };
      }
    } catch (err) {
      console.warn('[IA] Ollama no disponible, usando fallback de reglas:', err.message);
    }

    // Fallback: usar explicación generada por reglas (ya guardada en el plan)
    const fallback = plan.explicacion_ia || 'No hay explicación disponible.';
    return { fuente: 'reglas', texto: fallback };
  },

  _construirPrompt(plan) {
    const recomendadas = plan.materias.filter(m => m.recomendada);
    const rechazadas   = plan.materias.filter(m => !m.recomendada);

    const listaMaterias = recomendadas
      .map(m => `- ${m.nombre} (${m.dificultad}, ${m.horas_cursada}hs cursada + ${m.horas_estudio?.toFixed(1)}hs estudio)`)
      .join('\n');

    const listaRechazadas = rechazadas
      .slice(0, 5)
      .map(m => `- ${m.nombre}: ${m.motivo_rechazo}`)
      .join('\n');

    return `Eres un asistente académico universitario. Explica en español, de forma clara y amigable (máximo 150 palabras), por qué se recomienda esta planificación académica:

Estrategia aplicada: ${plan.estrategia || 'equilibrada'}
Materias recomendadas:
${listaMaterias || 'Ninguna'}

Materias no recomendadas:
${listaRechazadas || 'Ninguna'}

Carga horaria total estimada: ${plan.horas_estudio_semanales?.toFixed(1) || 0} horas/semana.

Responde directamente sin encabezados ni listas, en tono cercano.`;
  },

  async _llamarOllama(prompt) {
    // Usamos fetch nativo (Node 18+) con AbortController para timeout
    const controller = new AbortController();
    const timeoutId  = setTimeout(() => controller.abort(), TIMEOUT_MS);

    try {
      const response = await fetch(`${OLLAMA_URL}/api/generate`, {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({
          model:  OLLAMA_MODEL,
          prompt,
          stream: false
        }),
        signal: controller.signal
      });

      clearTimeout(timeoutId);

      if (!response.ok) throw new Error(`Ollama respondio con status ${response.status}`);

      const data = await response.json();
      return data.response || null;
    } catch (err) {
      clearTimeout(timeoutId);
      throw err;
    }
  }
};

module.exports = IaService;
