const XLSX = require('xlsx');
const MateriaModel = require('../models/materia.model');
const { getDb } = require('../database/db');

const COLUMNAS_REQUERIDAS = [
  'Codigo', 'Materia', 'Anio', 'Cuatrimestre',
  'HorasSemanales', 'Correlativas', 'Dificultad', 'Promocionable'
];

const DIFICULTADES_VALIDAS = ['BAJA', 'MEDIA', 'ALTA', 'CRITICA'];

const ExcelService = {

  async parsearYGuardar(filePath, carreraId, nombreArchivo) {
    const workbook = XLSX.readFile(filePath);
    const sheet = workbook.Sheets[workbook.SheetNames[0]];
    const rows  = XLSX.utils.sheet_to_json(sheet, { defval: '' });

    if (!rows.length) throw new Error('El archivo Excel esta vacio.');

    // ── Validar columnas ────────────────────────────────────────────────────
    const cols = Object.keys(rows[0]);
    const faltantes = COLUMNAS_REQUERIDAS.filter(c => !cols.includes(c));
    if (faltantes.length) {
      throw new Error(`Columnas faltantes en el Excel: ${faltantes.join(', ')}`);
    }

    // ── Validar filas ───────────────────────────────────────────────────────
    const errores = [];
    const codigos = new Set();

    for (let i = 0; i < rows.length; i++) {
      const fila = i + 2; // header en fila 1
      const r = rows[i];

      if (!r.Codigo)           errores.push(`Fila ${fila}: Codigo vacio.`);
      if (!r.Materia)          errores.push(`Fila ${fila}: Nombre de materia vacio.`);
      if (!r.Anio || isNaN(Number(r.Anio))) errores.push(`Fila ${fila}: Anio invalido.`);
      if (![1,2,'1','2'].includes(r.Cuatrimestre)) errores.push(`Fila ${fila}: Cuatrimestre debe ser 1 o 2.`);
      if (!r.HorasSemanales || isNaN(Number(r.HorasSemanales)) || Number(r.HorasSemanales) <= 0)
        errores.push(`Fila ${fila}: HorasSemanales invalido.`);

      const dif = String(r.Dificultad).toUpperCase().trim();
      if (!DIFICULTADES_VALIDAS.includes(dif))
        errores.push(`Fila ${fila}: Dificultad invalida '${r.Dificultad}'. Valores: ${DIFICULTADES_VALIDAS.join(', ')}.`);

      if (codigos.has(String(r.Codigo).trim()))
        errores.push(`Fila ${fila}: Codigo duplicado '${r.Codigo}'.`);
      codigos.add(String(r.Codigo).trim());
    }

    if (errores.length) throw new Error(`Errores en el Excel:\n${errores.join('\n')}`);

    // ── Validar correlativas (referencias deben existir en el mismo archivo) ─
    for (let i = 0; i < rows.length; i++) {
      const fila = i + 2;
      const r = rows[i];
      if (!r.Correlativas) continue;
      const corrs = String(r.Correlativas).split(',').map(s => s.trim()).filter(Boolean);
      for (const c of corrs) {
        if (!codigos.has(c))
          errores.push(`Fila ${fila}: Correlativa '${c}' no existe en el plan.`);
      }
    }
    if (errores.length) throw new Error(`Errores en correlativas:\n${errores.join('\n')}`);

    // ── Guardar en base de datos ────────────────────────────────────────────
    const db = getDb();

    const guardar = db.transaction(() => {
      // Limpiar materias previas de esta carrera
      MateriaModel.deleteByCarrera(carreraId);

      // Insertar materias
      const mapaIds = {};
      for (const r of rows) {
        const result = MateriaModel.create({
          codigo:         String(r.Codigo).trim(),
          nombre:         String(r.Materia).trim(),
          anio:           Number(r.Anio),
          cuatrimestre:   Number(r.Cuatrimestre),
          horasSemanales: Number(r.HorasSemanales),
          dificultad:     String(r.Dificultad).toUpperCase().trim(),
          promocionable:  String(r.Promocionable).toLowerCase() === 'si'
                          || r.Promocionable === true || r.Promocionable === 1,
          carreraId
        });
        mapaIds[String(r.Codigo).trim()] = result.lastInsertRowid;
      }

      // Insertar correlatividades
      for (const r of rows) {
        if (!r.Correlativas) continue;
        const corrs = String(r.Correlativas).split(',').map(s => s.trim()).filter(Boolean);
        const materiaId = mapaIds[String(r.Codigo).trim()];
        for (const c of corrs) {
          const corrId = mapaIds[c];
          if (corrId) MateriaModel.insertCorrelatividad(materiaId, corrId);
        }
      }

      // Registrar el plan de estudio
      db.prepare(`
        INSERT INTO plan_estudio (nombre_archivo, carrera_id)
        VALUES (?,?)
      `).run(nombreArchivo, carreraId);

      return Object.keys(mapaIds).length;
    });

    const totalMaterias = guardar();

    return {
      mensaje: `Se importaron ${totalMaterias} materias correctamente.`,
      totalMaterias,
      carreraId
    };
  }
};

module.exports = ExcelService;
